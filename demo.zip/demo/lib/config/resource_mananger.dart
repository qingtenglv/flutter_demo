class ImageHelper {
  static String connectAssets(String path) {
    return "images/" + path;
  }
}
