import 'package:demo/ui/page/splash_page.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:demo/ui/page/tab/tab_navigator.dart';

class RouteName {
  static const String SPLASH = "splash";
  static const String TAB_NAVIGATOR = "/";
}

class Router {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case RouteName.SPLASH:
        return NoAnimationPageRoute(SplashPage());
      case RouteName.TAB_NAVIGATOR:
        return NoAnimationPageRoute(TabNavigator());
      default:
        return CupertinoPageRoute(
            builder: (_) => Scaffold(
                  body: Center(
                    child: Text(""),
                  ),
                ));
    }
  }
}

class NoAnimationPageRoute extends PageRouteBuilder {
  final Widget page;

  NoAnimationPageRoute(this.page)
      : super(
            opaque: false,
            pageBuilder: (context, a, sa) => page,
            transitionDuration: Duration(milliseconds: 0),
            transitionsBuilder: (c, a, sa, child) => child);
}
