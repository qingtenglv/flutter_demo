import 'package:demo/provider/exception.dart';
import 'package:dio/dio.dart';
import 'package:dio/native_imp.dart';

final WanAndroidApi api = WanAndroidApi();

class WanAndroidApi extends DioForNative {
  WanAndroidApi() {
    interceptors..add(ApiInterceptor());
  }
}

class ApiInterceptor extends InterceptorsWrapper {
  @override
  onResponse(Response response) {
    ResponseData data = ResponseData.fromJson(response.data);
    if (data.isSuccess) {
      response.data = data.data;
      return api.resolve(response);
    } else {
      if (data.code == -1001) {
        throw UnAuthException();
      } else {
        throw FailedException.fromResponseData(data);
      }
    }
  }
}

class ResponseData {
  int code = 0;
  String message;
  dynamic data;

  bool get isSuccess => code == 0;

  ResponseData.fromJson(Map<String, dynamic> json) {
    code = json["errorCode"];
    message = json["errorMsg"];
    data = json["data"];
  }
}
