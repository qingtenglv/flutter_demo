import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:oktoast/oktoast.dart';
import 'package:demo/config/storage_manager.dart';
import 'package:demo/config/router_manager.dart';
import 'package:demo/view_model/theme_model.dart';

List<SingleChildCloneableWidget> providers = [
  ChangeNotifierProvider<ThemeModel>(
      builder: (BuildContext context) => ThemeModel()),
];

void main() async {
  Provider.debugCheckInvalidValueType = null;
  await StorageManager.init();
  runApp(App());
}

class App extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return OKToast(
        child: MultiProvider(
      providers: providers,
      child: Consumer<ThemeModel>(
          builder: (BuildContext context, ThemeModel themeModel, Widget child) {
        return MaterialApp(
          theme: themeModel.themeData(),
          darkTheme:themeModel.themeData(isDarkMode: true),
          onGenerateRoute:Router.generateRoute,
          initialRoute: RouteName.SPLASH,
        );
      }),
    ));
  }
}
