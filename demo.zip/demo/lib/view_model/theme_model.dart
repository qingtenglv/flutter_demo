import 'package:demo/config/storage_manager.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ThemeModel extends ChangeNotifier {
  static const KEY_THEME_INDEX = "key_theme_index";
  static const KEY_DARK_MODE = "key_dark_mode";

  MaterialColor _themeColor;
  bool _isDarkMode;

  ThemeModel() {
    int index = StorageManager.sharedPreferences.get(KEY_THEME_INDEX) ?? 0;
    _themeColor = Colors.primaries[index];
    _isDarkMode = StorageManager.sharedPreferences.get(KEY_DARK_MODE) ?? false;
  }

  switchThemeMode({MaterialColor themeColor, bool isDarkMode}) {
    _themeColor = themeColor ?? _themeColor;
    _isDarkMode = isDarkMode ?? _isDarkMode;
    saveThemeColor2Storage();
    notifyListeners();
  }

  ThemeData themeData({bool isDarkMode: false}) {
    isDarkMode = _isDarkMode || isDarkMode;
    return ThemeData(
        brightness: isDarkMode ? Brightness.dark : Brightness.light,
        primarySwatch: _themeColor,
        iconTheme: IconThemeData(color: _themeColor));
  }

  saveThemeColor2Storage() async {
    await StorageManager.sharedPreferences.setBool(KEY_DARK_MODE, _isDarkMode);
    await StorageManager.sharedPreferences
        .setInt(KEY_THEME_INDEX, Colors.primaries.indexOf(_themeColor));
  }
}
