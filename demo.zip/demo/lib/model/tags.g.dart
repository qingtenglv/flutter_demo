// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'tags.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Tags _$TagsFromJson(Map<String, dynamic> json) {
  return Tags()
    ..url = json['url'] as String
    ..name = json['name'] as String;
}

Map<String, dynamic> _$TagsToJson(Tags instance) =>
    <String, dynamic>{'url': instance.url, 'name': instance.name};
