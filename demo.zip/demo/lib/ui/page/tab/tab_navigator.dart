import 'package:flutter/material.dart';

class TabNavigator extends StatelessWidget {
 @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(body: Text("test"),);
  }
}

//class TabState extends State<TabNavigator>{
//
//  @override
//  void initState() {
//    // TODO: implement initState
//    super.initState();
//  }
//
//  @override
//  Widget build(BuildContext context) {
//    // TODO: implement build
//    return Scaffold();
//  }
//}

