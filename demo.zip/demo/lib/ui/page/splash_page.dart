import 'package:demo/config/resource_mananger.dart';
import 'package:demo/view_model/theme_model.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:demo/config/router_manager.dart';

class SplashPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return SplashState();
  }
}

class SplashState extends State<SplashPage> with TickerProviderStateMixin {
  AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller =
        new AnimationController(vsync: this, duration: Duration(seconds: 2));
    _controller.addStatusListener((AnimationStatus status){
        if(status==AnimationStatus.completed){
           Navigator.of(context).pushReplacementNamed(RouteName.TAB_NAVIGATOR);
        }
    });
    _controller.forward();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
        animation: _controller,
        builder: (BuildContext context, Widget child) {
          return Scaffold(
            body: Container(
              color: Theme.of(context).primaryColor,
              child: Center(
                child: Image.asset(
                  ImageHelper.connectAssets("ic_launcher_foreground.png"),
                  width: 200,
                  height: 200,
                  color: Colors.blue,
                ),
              ),
            ),
          );
        });
  }
}
